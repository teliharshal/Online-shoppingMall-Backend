package com.example.ShoppingApp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ShoppingApp.model.Shop;
import com.example.ShoppingApp.repository.ShopRepository;

@Service
public class ShopService {

    @Autowired
    private ShopRepository shopRepository;

    // Create a new Shop
    public Shop createShop(Shop shop) {
        return shopRepository.save(shop);
    }

    // Get Shop by ID
    public Optional<Shop> getShopById(int id) {
        return shopRepository.findById(id);
    }

    // Get all Shops
    public List<Shop> getAllShops() {
        return shopRepository.findAll();
    }

    // Update Shop
    public Shop updateShop(Shop shop) {
        return shopRepository.save(shop);
    }

    // Delete Shop by ID
    public void deleteShop(int id) {
        shopRepository.deleteById(id);
    }

}
