package com.example.ShoppingApp.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
@Entity
public class Shop {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
	private int shopIdentity;	
    private String shopCategory;    
    @OneToMany(mappedBy = "shop_id", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Employee> shopEmployeeID;
    @OneToMany(mappedBy = "shop", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Item> items;
    private String shopName;     
    @ManyToMany
    @JoinTable(
        name = "shop_customer",  // The name of the join table
        joinColumns = @JoinColumn(name = "shop_id"),  // Foreign key for Student
        inverseJoinColumns = @JoinColumn(name = "customer_id")  // Foreign key for Course
    )
    private List<Customer> customers;   
    private String shopStatus;     
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "shopOwner_id", referencedColumnName = "id")
    private ShopOwner shopOwner;    
    private String leaseStatus;
    @ManyToOne  
    @JoinColumn(name = "mall_id", referencedColumnName = "id")
    private Mall mall;
    private boolean isApproved;
    
	@Override
	public String toString() {
		return "Shop [id=" + id + ", shopIdentity=" + shopIdentity + ", shopCategory=" + shopCategory + ", shopEmployeeID="
				+ shopEmployeeID + ", shopName=" + shopName + ", customers=" + customers + ", shopStatus=" + shopStatus
				+ ", shopOwner=" + shopOwner + ", leaseStatus=" + leaseStatus +", isApproved="+isApproved+ "]";
	}
	public Shop() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Shop(int id, int shopIdentity, String shopCategory, List<Employee> shopEmployeeID, String shopName, List<Customer> customers,
			String shopStatus, ShopOwner shopOwner, String leaseStatus, boolean isApproved) {
		super();
		this.id = id;
		this.shopIdentity = shopIdentity;
		this.shopCategory = shopCategory;
		this.shopEmployeeID = shopEmployeeID;
		this.shopName = shopName;
		this.customers = customers;
		this.shopStatus = shopStatus;
		this.shopOwner = shopOwner;
		this.leaseStatus = leaseStatus;
		this.isApproved = isApproved;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getShopIdentity() {
		return shopIdentity;
	}
	public void setShopIdentity(int shopId) {
		this.shopIdentity = shopId;
	}
	public String getShopCategory() {
		return shopCategory;
	}
	public void setShopCategory(String shopCategory) {
		this.shopCategory = shopCategory;
	}
	public List<Employee> getShopEmployeeID() {
		return shopEmployeeID;
	}
	public void setShopEmployeeID(List<Employee> shopEmployeeID) {
		this.shopEmployeeID = shopEmployeeID;
	}
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public List<Customer> getCustomers() {
		return customers;
	}
	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}
	public String getShopStatus() {
		return shopStatus;
	}
	public void setShopStatus(String shopStatus) {
		this.shopStatus = shopStatus;
	}
	public ShopOwner getShopOwner() {
		return shopOwner;
	}
	public void setShopOwner(ShopOwner shopOwner) {
		this.shopOwner = shopOwner;
	}
	public String getLeaseStatus() {
		return leaseStatus;
	}
	public void setLeaseStatus(String leaseStatus) {
		this.leaseStatus = leaseStatus;
	}
	public boolean isApproved() {
		return isApproved;
	}
	public void setApproved(boolean isApproved) {
		this.isApproved = isApproved;
	}
    
    

    
	
}
