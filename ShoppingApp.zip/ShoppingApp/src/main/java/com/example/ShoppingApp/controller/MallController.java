package com.example.ShoppingApp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ShoppingApp.model.Item;
import com.example.ShoppingApp.model.Mall;
import com.example.ShoppingApp.model.User;
import com.example.ShoppingApp.service.MallService;
import com.example.ShoppingApp.service.UserService;

@RestController
@RequestMapping("/api/mall")
public class MallController {

	@Autowired
    private MallService mallItemService;
	
	@Autowired
	private UserService userService;

    // CRUD operations for Mall

    // Create Mall
    @PostMapping("/malls")
    public ResponseEntity<Mall> createMall(@RequestBody Mall mall) {
        Mall createdMall = mallItemService.createMall(mall);
        return ResponseEntity.ok(createdMall);
    }

    // Get Mall by ID
    @GetMapping("/malls/{id}")
    public ResponseEntity<Mall> getMallById(@PathVariable int id) {
        Optional<Mall> mall = mallItemService.getMallById(id);
        return mall.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Get all Malls
    @GetMapping("/malls")
    public ResponseEntity<List<Mall>> getAllMalls() {
        List<Mall> malls = mallItemService.getAllMalls();
        return ResponseEntity.ok(malls);
    }

    // Update Mall
    @PutMapping("/malls")
    public ResponseEntity<Mall> updateMall(@RequestBody Mall mall) {
        Mall updatedMall = mallItemService.updateMall(mall);
        return ResponseEntity.ok(updatedMall);
    }

    // Delete Mall
    @DeleteMapping("/malls/{id}")
    public ResponseEntity<Void> deleteMall(@PathVariable int id) {
        mallItemService.deleteMall(id);
        return ResponseEntity.ok().build();
    }

    // CRUD operations for Item

    // Create Item
    @PostMapping("/items")
    public ResponseEntity<Item> createItem(@RequestBody Item item) {
        Item createdItem = mallItemService.createItem(item);
        return ResponseEntity.ok(createdItem);
    }

    // Get Item by ID
    @GetMapping("/items/{id}")
    public ResponseEntity<Item> getItemById(@PathVariable int id) {
        Optional<Item> item = mallItemService.getItemById(id);
        return item.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Get all Items
    @GetMapping("/items")
    public ResponseEntity<List<Item>> getAllItems() {
        List<Item> items = mallItemService.getAllItems();
        return ResponseEntity.ok(items);
    }

    // Update Item
    @PutMapping("/items")
    public ResponseEntity<Item> updateItem(@RequestBody Item item) {
        Item updatedItem = mallItemService.updateItem(item);
        return ResponseEntity.ok(updatedItem);
    }

    // Delete Item
    @DeleteMapping("/items/{id}")
    public ResponseEntity<Void> deleteItem(@PathVariable int id) {
        mallItemService.deleteItem(id);
        return ResponseEntity.ok().build();
    }
    
    // Create user
    @PostMapping("/users")
    public ResponseEntity<User> createUser(@RequestBody User user) {
        User createdUser = userService.adduser(user);
        return ResponseEntity.ok(createdUser);
    }

    // Get user by ID
    @GetMapping("/users/{id}")
    public ResponseEntity<User> getUserById(@PathVariable int id) {
        Optional<User> user = userService.getUserById(id);
        return user.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Get all users
    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userService.getAllUser();
        return ResponseEntity.ok(users);
    }

    // Update user
    @PutMapping("/users")
    public ResponseEntity<User> updateUser(@RequestBody User user) {
        User updatedUser = userService.updateUser(user);
        return ResponseEntity.ok(updatedUser);
    }

    // Delete user
    @DeleteMapping("/users/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable int id) {
        userService.deleteUser(id);
        return ResponseEntity.ok().build();
    }
}
