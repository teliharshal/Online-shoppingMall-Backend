package com.example.ShoppingApp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ShoppingApp.model.User;
import com.example.ShoppingApp.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;

	public User adduser(User user) {
		return userRepository.save(user);
	}

	public Optional<User> getUserById(int Id) {
		return userRepository.findById(Id);
	}


	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}


	public User updateUser(User user) {
		Optional<User> userOptional = userRepository.findById(user.getId());
	    
	    // Check if the shop is present
	    if (userOptional.isPresent()) {
	    	 User existingUser = userOptional.get();
	         
	         // Update the fields with new values
	    	 existingUser.setName(user.getName()); // Example field update
	    	 existingUser.setType(user.getType()); // Example field update
	    	 existingUser.setPassword(user.getPassword()); // Example field update
	         // Add any other fields that need to be updated here
	         // Save the updated mall admin back to the repository
	         return userRepository.save(existingUser);
	    }
		return null;// TODO Auto-generated method stub
	}

	public void deleteUser(int id) {
		// TODO Auto-generated method stub
		userRepository.deleteById(id);
	}
	
}
