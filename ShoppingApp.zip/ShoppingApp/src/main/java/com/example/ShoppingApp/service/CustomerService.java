package com.example.ShoppingApp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ShoppingApp.model.Customer;
import com.example.ShoppingApp.model.Item;
import com.example.ShoppingApp.model.Mall;
import com.example.ShoppingApp.model.OrderDetails;
import com.example.ShoppingApp.model.User;
import com.example.ShoppingApp.repository.CustomerRepository;
import com.example.ShoppingApp.repository.ItemRepository;
import com.example.ShoppingApp.repository.MallRepository;
import com.example.ShoppingApp.repository.OrderRepository;

@Service
public class CustomerService {

	    @Autowired
	    private ItemRepository itemRepository;

	    @Autowired
	    private MallRepository mallRepository;

	    @Autowired
	    private OrderRepository orderRepository;

	    @Autowired
	    private CustomerRepository customerRepository;

	    // Search for an item by name
	    public List<Item> searchItem(String itemName) {
	        return itemRepository.findByName(itemName);
	    }

	    // Place an order for an item
	    public OrderDetails orderItem(OrderDetails order) {
	        return orderRepository.save(order);
	    }

	    // Search for a mall by ID
	    public Optional<Mall> searchMall(int id) {
	        return mallRepository.findById(id);
	    }

	    // Cancel an order by ID
	    public boolean cancelOrder(int orderId) {
	        Optional<OrderDetails> orderOptional = orderRepository.findById(orderId);
	        if (orderOptional.isPresent()) {
	            orderRepository.delete(orderOptional.get());
	            return true;
	        } else {
	            return false; // Order not found
	        }
	    }

	    // Login a user
	    public Optional<User> login(String name, String password) {
	        return customerRepository.findByNameAndPassword(name, password);
	    }

	    // Logout (dummy implementation)
	    public boolean logOut() {
	        return true; // Just returns true for now as no session is handled
	    }

	    // CRUD operations for Customer

	    // Create a new customer
	    public Customer createCustomer(Customer customer) {
	        return customerRepository.save(customer);
	    }

	    // Get customer by ID
	    public Optional<Customer> getCustomerById(int id) {
	        return customerRepository.findById(id);
	    }

	    // Get all customers
	    public List<Customer> getAllCustomers() {
	        return customerRepository.findAll();
	    }

	    // Update customer
	    public Customer updateCustomer(Customer customer) {
	        return customerRepository.save(customer);
	    }

	    // Delete customer by ID
	    public void deleteCustomer(int id) {
	        customerRepository.deleteById(id);
	    }
	   

	
}
