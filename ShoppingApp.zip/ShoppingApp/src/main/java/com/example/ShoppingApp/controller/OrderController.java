package com.example.ShoppingApp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ShoppingApp.model.OrderDetails;
import com.example.ShoppingApp.service.OrderService;

@RestController
@RequestMapping("/api/orderdetails")
public class OrderController {
	
	@Autowired
    private OrderService orderDetailsService;

    // Create new OrderDetails
    @PostMapping
    public ResponseEntity<OrderDetails> createOrderDetails(@RequestBody OrderDetails orderDetails) {
        OrderDetails createdOrderDetails = orderDetailsService.createOrderDetails(orderDetails);
        return ResponseEntity.ok(createdOrderDetails);
    }

    // Get OrderDetails by ID
    @GetMapping("/{id}")
    public ResponseEntity<OrderDetails> getOrderDetailsById(@PathVariable int id) {
        Optional<OrderDetails> orderDetails = orderDetailsService.getOrderDetailsById(id);
        return orderDetails.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Get all OrderDetails
    @GetMapping
    public ResponseEntity<List<OrderDetails>> getAllOrderDetails() {
        List<OrderDetails> orderDetailsList = orderDetailsService.getAllOrderDetails();
        return ResponseEntity.ok(orderDetailsList);
    }

    // Update OrderDetails
    @PutMapping
    public ResponseEntity<OrderDetails> updateOrderDetails(@RequestBody OrderDetails orderDetails) {
        OrderDetails updatedOrderDetails = orderDetailsService.updateOrderDetails(orderDetails);
        return ResponseEntity.ok(updatedOrderDetails);
    }

    // Delete OrderDetails by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrderDetails(@PathVariable int id) {
        orderDetailsService.deleteOrderDetails(id);
        return ResponseEntity.ok().build();
    }
	
}
