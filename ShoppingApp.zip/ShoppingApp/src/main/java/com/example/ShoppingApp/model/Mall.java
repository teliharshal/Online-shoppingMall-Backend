package com.example.ShoppingApp.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
@Entity
public class Mall {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
	@OneToOne
    @JoinColumn(name = "mall")
    private MallAdmin mallAdmin;
    private String mallName;
    private String location;
    @OneToMany(mappedBy = "mall", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Shop> shops_id;
    private String categories;

	@Override
	public String toString() {
		return "Mall [id=" + id + ", mallAdmin=" + mallAdmin + ", mallName=" + mallName + ", location=" + location
				+ ", shops_id=" + shops_id + ", categories=" + categories + "]";
	}
	public Mall() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Mall(long id, MallAdmin mallAdmin, String mallName, String location, List<Shop> shops_id, String categories) {
		super();
		this.id = id;
		this.mallAdmin = mallAdmin;
		this.mallName = mallName;
		this.location = location;
		this.shops_id = shops_id;
		this.categories = categories;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public MallAdmin getMallAdmin() {
		return mallAdmin;
	}
	public void setMallAdmin(MallAdmin mallAdmin) {
		this.mallAdmin = mallAdmin;
	}
	public String getMallName() {
		return mallName;
	}
	public void setMallName(String mallName) {
		this.mallName = mallName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public List<Shop> getShops_id() {
		return shops_id;
	}
	public void setShops_id(List<Shop> shops_id) {
		this.shops_id = shops_id;
	}
	public String getCategories() {
		return categories;
	}
	public void setCategories(String categories) {
		this.categories = categories;
	}

}
