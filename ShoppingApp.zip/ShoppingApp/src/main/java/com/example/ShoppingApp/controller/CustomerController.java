package com.example.ShoppingApp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.ShoppingApp.model.Customer;
import com.example.ShoppingApp.model.Item;
import com.example.ShoppingApp.model.Mall;
import com.example.ShoppingApp.model.OrderDetails;
import com.example.ShoppingApp.model.User;
import com.example.ShoppingApp.service.CustomerService;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {
	
	 @Autowired
	 private CustomerService customerService;

	    // Create a new customer
	    @PostMapping
	    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
	        Customer createdCustomer = customerService.createCustomer(customer);
	        return ResponseEntity.ok(createdCustomer);
	    }

	    // Get a customer by ID
	    @GetMapping("/{id}")
	    public ResponseEntity<Customer> getCustomerById(@PathVariable int id) {
	        Optional<Customer> customer = customerService.getCustomerById(id);
	        return customer.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	    }

	    // Get all customers
	    @GetMapping
	    public ResponseEntity<List<Customer>> getAllCustomers() {
	        List<Customer> customers = customerService.getAllCustomers();
	        return ResponseEntity.ok(customers);
	    }

	    // Update customer
	    @PutMapping
	    public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer) {
	        Customer updatedCustomer = customerService.updateCustomer(customer);
	        return ResponseEntity.ok(updatedCustomer);
	    }

	    // Delete customer by ID
	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> deleteCustomer(@PathVariable int id) {
	        customerService.deleteCustomer(id);
	        return ResponseEntity.ok().build();
	    }

	    // Search for an item by name
	    @GetMapping("/items/search")
	    public ResponseEntity<List<Item>> searchItem(@RequestParam String itemName) {
	        List<Item> items = customerService.searchItem(itemName);
	        return ResponseEntity.ok(items);
	    }

	    // Order an item
	    @PostMapping("/orders")
	    public ResponseEntity<OrderDetails> orderItem(@RequestBody OrderDetails order) {
	        OrderDetails createdOrder = customerService.orderItem(order);
	        return ResponseEntity.ok(createdOrder);
	    }

	    // Search a mall by ID
	    @GetMapping("/malls/{id}")
	    public ResponseEntity<Mall> searchMall(@PathVariable int id) {
	        Optional<Mall> mall = customerService.searchMall(id);
	        if (mall.isPresent()) {
	            return ResponseEntity.ok(mall.get());
	        } else {
	            return ResponseEntity.notFound().build(); // Mall not found
	        }
	    }

	    // Cancel an order
	    @DeleteMapping("/orders/{orderId}")
	    public ResponseEntity<Boolean> cancelOrder(@PathVariable int orderId) {
	        boolean result = customerService.cancelOrder(orderId);
	        if (result) {
	            return ResponseEntity.ok(true); // Order cancelled
	        } else {
	            return ResponseEntity.status(404).body(false); // Order not found
	        }
	    }

	    // User login
	    @PostMapping("/login")
	    public ResponseEntity<User> login(@RequestBody User user) {
	        Optional<User> loggedInUser = customerService.login(user.getName(), user.getPassword());
	        if (loggedInUser.isPresent()) {
	            return ResponseEntity.ok(loggedInUser.get());
	        } else {
	            return ResponseEntity.status(401).build(); // Unauthorized
	        }
	    }

	    // User logout (dummy)
	    @PostMapping("/logout")
	    public ResponseEntity<Boolean> logOut() {
	        return ResponseEntity.ok(customerService.logOut()); // Always returns true
	    }
}
