package com.example.ShoppingApp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ShoppingApp.model.Employee;
import com.example.ShoppingApp.repository.EmployeeRepository;

@Service
public class EmployeeService {

	  @Autowired
	    private EmployeeRepository employeeRepository;

	    // Create a new Employee
	    public Employee createEmployee(Employee employee) {
	        return employeeRepository.save(employee);
	    }

	    // Get Employee by ID
	    public Optional<Employee> getEmployeeById(int id) {
	        return employeeRepository.findById(id);
	    }

	    // Get all Employees
	    public List<Employee> getAllEmployees() {
	        return employeeRepository.findAll();
	    }

	    // Update Employee
	    public Employee updateEmployee(Employee employee) {
	        return employeeRepository.save(employee);
	    }

	    // Delete Employee by ID
	    public void deleteEmployee(int id) {
	        employeeRepository.deleteById(id);
	    }
	
}
