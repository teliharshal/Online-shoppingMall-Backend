package com.example.ShoppingApp.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;

@Entity
public class Customer {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;	
    private String name;    
    private String password;
	@OneToMany(mappedBy = "customer_id", cascade = CascadeType.ALL)
    private List<OrderDetails> order_id;    
    private String phone;    
    private String email;
    @ManyToMany(mappedBy = "customers")  // Define the foreign key column for the relationship
    private List<Shop> shop_id;
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", order_id=" + order_id + ", phone=" + phone + ", email="
				+ email + ", shop_id=" + shop_id + ", password=" + password+"]";
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(int id, String name, List<OrderDetails> order_id, String phone, String email, List<Shop> shop_id, String password) {
		super();
		this.id = id;
		this.name = name;
		this.order_id = order_id;
		this.phone = phone;
		this.email = email;
		this.shop_id = shop_id;
		this.password=password;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
    public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public List<OrderDetails> getOrder_id() {
		return order_id;
	}
	public void setOrder_id(List<OrderDetails> order_id) {
		this.order_id = order_id;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<Shop> getShop_id() {
		return shop_id;
	}
	public void setShop_id(List<Shop> shop_id) {
		this.shop_id = shop_id;
	}
	

	
}
