package com.example.ShoppingApp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ShoppingApp.model.Item;
import com.example.ShoppingApp.model.Mall;
import com.example.ShoppingApp.repository.ItemRepository;
import com.example.ShoppingApp.repository.MallRepository;

@Service
public class MallService {

	@Autowired
    private MallRepository mallRepository;

    @Autowired
    private ItemRepository itemRepository;

    // CRUD operations for Mall

    public Mall createMall(Mall mall) {
        return mallRepository.save(mall);
    }

    public Optional<Mall> getMallById(int id) {
        return mallRepository.findById(id);
    }

    public List<Mall> getAllMalls() {
        return mallRepository.findAll();
    }

    public Mall updateMall(Mall mall) {
        return mallRepository.save(mall);
    }

    public void deleteMall(int id) {
        mallRepository.deleteById(id);
    }

    // CRUD operations for Item

    public Item createItem(Item item) {
        return itemRepository.save(item);
    }

    public Optional<Item> getItemById(int id) {
        return itemRepository.findById(id);
    }

    public List<Item> getAllItems() {
        return itemRepository.findAll();
    }

    public Item updateItem(Item item) {
        return itemRepository.save(item);
    }

    public void deleteItem(int id) {
        itemRepository.deleteById(id);
    }
}
