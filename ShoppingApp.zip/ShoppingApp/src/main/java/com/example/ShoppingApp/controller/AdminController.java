package com.example.ShoppingApp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.ShoppingApp.model.MallAdmin;
import com.example.ShoppingApp.service.AdminService;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

	@Autowired
    private AdminService adminService;

    // Approve or reject a new shop
    @PostMapping("/approveShop/{shopId}")
    public ResponseEntity<Boolean> approveNewShop(@PathVariable int shopId, @RequestParam boolean approve) {
        boolean result = adminService.approveShop(shopId, approve);
        if (result) {
            return ResponseEntity.ok(true);
        } else {
            return ResponseEntity.status(404).body(false); // Shop not found
        }
    }

    // Update user (admin) information
    @PutMapping("/updateUser")
    public ResponseEntity<MallAdmin> updateUser(@RequestBody MallAdmin mallAdmin) {
        MallAdmin updatedAdmin = adminService.updateAdmin(mallAdmin);
        if (updatedAdmin != null) {
            return ResponseEntity.ok(updatedAdmin);
        } else {
            return ResponseEntity.status(404).build(); // Admin not found
        }
    }

    // Login as an admin
    @PostMapping("/login")
    public ResponseEntity<MallAdmin> login(@RequestBody MallAdmin adminDetails) {
        Optional<MallAdmin> admin = adminService.getAdminById(adminDetails.getId());
        if (admin.isPresent() && admin.get().getPassword().equals(adminDetails.getPassword())) {
            return ResponseEntity.ok(admin.get());
        } else {
            return ResponseEntity.status(401).build(); // Unauthorized (invalid credentials)
        }
    }

    // Logout (dummy implementation, since session management is not part of this)
    @PostMapping("/logout")
    public ResponseEntity<Boolean> logOut() {
        return ResponseEntity.ok(true); // Successfully logged out
    }
    
    @PostMapping("/create")
    public ResponseEntity<MallAdmin> createAdmin(@RequestBody MallAdmin mallAdmin) {
        MallAdmin newAdmin = adminService.addAdmin(mallAdmin);
        return ResponseEntity.ok(newAdmin); // Return the newly created admin
    }

    // Get an admin by ID
    @GetMapping("/get/{adminId}")
    public ResponseEntity<MallAdmin> getAdminById(@PathVariable int adminId) {
        Optional<MallAdmin> admin = adminService.getAdminById(adminId);
        if (admin.isPresent()) {
            return ResponseEntity.ok(admin.get());
        } else {
            return ResponseEntity.status(404).build(); // Admin not found
        }
    }

    // Get all admins
    @GetMapping("/getAll")
    public ResponseEntity<List<MallAdmin>> getAllAdmins() {
        List<MallAdmin> adminList = adminService.getAllAdmin();
        return ResponseEntity.ok(adminList); // Return the list of all admins
    }

    // Update an admin (already implemented as /updateUser)

    // Delete an admin by ID
    @DeleteMapping("/delete/{adminId}")
    public ResponseEntity<Void> deleteAdmin(@PathVariable int adminId) {
        Optional<MallAdmin> adminOptional = adminService.getAdminById(adminId);
        if (adminOptional.isPresent()) {
            adminService.deleteAdmin(adminOptional.get());
            return ResponseEntity.ok().build(); // Successfully deleted
        } else {
            return ResponseEntity.status(404).build(); // Admin not found
        }
    }

}
	
