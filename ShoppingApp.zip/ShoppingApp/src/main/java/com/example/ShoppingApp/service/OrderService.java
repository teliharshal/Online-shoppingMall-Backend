package com.example.ShoppingApp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ShoppingApp.model.OrderDetails;
import com.example.ShoppingApp.repository.OrderRepository;

@Service
public class OrderService {

	 @Autowired
	    private OrderRepository orderDetailsRepository;

	    // Create a new OrderDetails
	    public OrderDetails createOrderDetails(OrderDetails orderDetails) {
	        return orderDetailsRepository.save(orderDetails);
	    }

	    // Get OrderDetails by ID
	    public Optional<OrderDetails> getOrderDetailsById(int id) {
	        return orderDetailsRepository.findById(id);
	    }

	    // Get all OrderDetails
	    public List<OrderDetails> getAllOrderDetails() {
	        return orderDetailsRepository.findAll();
	    }

	    // Update OrderDetails
	    public OrderDetails updateOrderDetails(OrderDetails orderDetails) {
	        return orderDetailsRepository.save(orderDetails);
	    }

	    // Delete OrderDetails by ID
	    public void deleteOrderDetails(int id) {
	        orderDetailsRepository.deleteById(id);
	    }
	
}
