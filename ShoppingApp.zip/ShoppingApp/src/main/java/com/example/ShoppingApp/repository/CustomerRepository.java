package com.example.ShoppingApp.repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.ShoppingApp.model.Customer;
import com.example.ShoppingApp.model.User;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

	Optional<User> findByNameAndPassword(String name, String password);

}
