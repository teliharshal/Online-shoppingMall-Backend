package com.example.ShoppingApp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ShoppingApp.model.MallAdmin;
import com.example.ShoppingApp.model.Shop;
import com.example.ShoppingApp.repository.MallAdminRepository;
import com.example.ShoppingApp.repository.ShopRepository;


@Service
public class AdminService {
	@Autowired
	private MallAdminRepository mallAdminRepository;
	@Autowired
	private ShopRepository shopRepository;

	   

	public boolean approveShop(int id, boolean val) {
	    Optional<Shop> shopOptional = shopRepository.findById(id);
	    
	    // Check if the shop is present
	    if (shopOptional.isPresent()) {
	        // Get the shop from Optional
	        Shop shop = shopOptional.get();
	        
	        // Set the approved status
	        shop.setApproved(val);
	        
	        // Save the updated shop entity back to the database
	        shopRepository.save(shop);
	        
	        return true;  // Indicate success
	    } else {
	        return false;  // Shop not found, return false
	    }
	}



	public MallAdmin addAdmin(MallAdmin mallAdmin) {
		return mallAdminRepository.save(mallAdmin);
	}

	public Optional<MallAdmin> getAdminById(int Id) {
		return mallAdminRepository.findById(Id);
	}

	public List<MallAdmin> getAllAdmin() {
		// TODO Auto-generated method stub
		return mallAdminRepository.findAll();
	}

	public MallAdmin updateAdmin(MallAdmin mallAdmin) {
		// TODO Auto-generated method stub
		Optional<MallAdmin> mallAdminOptional = mallAdminRepository.findById(mallAdmin.getId());
	    
	    // Check if the shop is present
	    if (mallAdminOptional.isPresent()) {
	    	 MallAdmin existingAdmin = mallAdminOptional.get();
	         
	         // Update the fields with new values
	         existingAdmin.setName(mallAdmin.getName()); // Example field update
	         existingAdmin.setPassword(mallAdmin.getPassword()); // Example field update
	         existingAdmin.setPhone(mallAdmin.getPhone()); // Example field update
	         // Add any other fields that need to be updated here
	         
	         // Save the updated mall admin back to the repository
	         return mallAdminRepository.save(existingAdmin);
	        
	    }
		return null;
	}


	public void deleteAdmin(MallAdmin mallAdmin) {
		// TODO Auto-generated method stub
		mallAdminRepository.delete(mallAdmin);
	}
	
}
