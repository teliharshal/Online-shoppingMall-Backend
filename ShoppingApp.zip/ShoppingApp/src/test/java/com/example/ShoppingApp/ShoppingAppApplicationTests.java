package com.example.ShoppingApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
